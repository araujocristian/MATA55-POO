package teste;

import bar.Movimento;
import bar.Pedido;
import bar.Produto;
import bar.Bar;
import bar.Cliente;
import bar.Especial;
import bar.VIP;
import java.util.Calendar;
import java.util.Scanner;
/**
 *
 * @author cristian
 */
public class Aplicacao {
    public static void main(String[] args) {
        Bar bar1 = new Bar();
        Calendar c = Calendar.getInstance();

        Scanner teclado = new Scanner(System.in); 

        Movimento m1 = new Movimento(c,10);
        Movimento m2 = new Movimento(c,20);
        Movimento m3 = new Movimento(c,30);
        Movimento m4 = new Movimento(c,40);
        Movimento m5 = new Movimento(c,50);
        
        
        
        Cliente c1 = new Cliente(1, 0, 0, "Cliente1");
        Especial c2 = new Especial(2, 0, 1, "Cliente2","end","878945487", "email", 'M');
        VIP c3 = new VIP(3, 0, 2, "Cliente3","end","878945487", "email", 'M', 195, "gerente");
        Cliente c4 = new Cliente(4, 0, 0, "Cliente4");
        Cliente c5 = new Cliente(5, 0, 0, "Cliente5");
        
        Produto produto1 = new Produto(25,0,"Sabão");
        Pedido pedido1 = new Pedido(1,produto1);
        Movimento movimento1 = new Movimento(c,10);
        System.out.println("Data e Hora atual:"+c.getTime());
        
        System.out.println(produto1.getNome());
        System.out.println(pedido1.getStatus());
        System.out.println(movimento1.getDataAbertura());
        
    }
}
